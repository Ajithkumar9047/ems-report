﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace LeadPush
{
    public class Program
    {
        GUtils.DBUtils objDbu = new GUtils.DBUtils();
        ThresholdService thresholdService = new ThresholdService();
        static void Main(string[] args)
        {
            Program program = new Program();

            program.Get91WheelsEmsRepushData();

            // program.GetWebsiteEmsRepushData();
        }

        public void Get91WheelsEmsRepushData()
        {

            string Predate = DateTime.Now.AddDays(-1).ToString("dd/MM/yyyy");

            string currnentdate = DateTime.Now.ToString("dd/MM/yyyy");

            string qry = "select  top 100 * ";
            qry += " from tvs_91Wheels_leads  where CONVERT(date,create_date_get) ";
            qry += " between CONVERT(DATE,'" + Predate + "',103) and CONVERT(DATE,'" + currnentdate + "',103) ";
            qry += " and ISNULL(ems_server_response,'')='' and  ISNULL(dms_response,'')='' and isnull(repush_ems,0)=0 ";

            qry += "  and id not in(select crm.CRM_INTERNET_ENQUIRY_ID ";
            qry += "  from tb_tvs_common_crm_api_leads crm join tvs_91Wheels_leads web ";
            qry += "  on crm.CRM_INTERNET_ENQUIRY_ID = web.id ";
            qry += "  where CONVERT(date, web.create_date) ";
            qry += "  between CONVERT(date,'"+Predate+"',103) and CONVERT(date,'"+currnentdate+"',103) ";
            qry += " and ISNULL(web.ems_server_response,'')= '' ";
            qry += "  and ISNULL(web.dms_response,'')= '' ) ";


            DataSet ds = objDbu.executeQuery(qry);

            foreach (DataRow row in ds.Tables[0].Rows)
            {
                DropLeadRequestModel r = new DropLeadRequestModel();


                r.DEALER_ID = row["dealer_id"].ToString();
                r.BRANCH_ID = row["BRANCH_ID"].ToString();
                r.INTERNET_ENQUIRY_ID = row["INTERNET_ENQUIRY_ID"].ToString();
                r.CUSTOMER_NAME = row["name"].ToString();
                r.GENDER = row["GENDER"].ToString();
                r.MARRIED = row["MARRIED"].ToString();
                r.ADDRESS_LINE1 = row["ADDRESS_LINE1"].ToString();
                r.AREA = row["AREA"].ToString();
                r.MOBILE_NUMBER = row["mobile"].ToString();
                r.EMAIL_ID = row["email"].ToString();
                r.PART_ID = row["PART_ID"].ToString();
                r.MODEL_ID = row["MODEL_ID_DMS"].ToString();
                r.CUSTOMER_VOICE = row["CUSTOMER_VOICE"].ToString();
                r.Finance = row["Finance"].ToString();
                r.ENQUIRY_DATE = row["create_date_get"].ToString();
                DateTime dmsdate = Convert.ToDateTime(row["create_date_get"].ToString());
                string SOURCE = "91Wheels";
                string dateapiems = dmsdate.ToString("yyyy-MM-ddTHH:mm:ss.000Z");

                string Ems_Enquirydatanewjson = "{\"DEALER_ID\":\"" + r.DEALER_ID + "\"," +
              "\"BRANCH_ID\":\"" + r.BRANCH_ID + "\",\"INTERNET_ENQUIRY_ID\":\"" + r.INTERNET_ENQUIRY_ID + "\"," +
              "\"CUSTOMER_NAME\":\"" + r.CUSTOMER_NAME + "\",\"GENDER\":\"" + r.GENDER + "\",\"MARRIED\":\"" + r.MARRIED + "\"," +
              "\"ADDRESS_LINE1\":\"" + r.ADDRESS_LINE1 + "\",\"AREA\":\"" + r.AREA + "\"," +
              "\"PHONE_NUMBER\":\"" + r.MOBILE_NUMBER.Replace("+91", "") + "\"," +
              "\"MOBILE_NUMBER\":\"" + r.MOBILE_NUMBER.Replace("+91", "") + "\"," +
              "\"EMAIL_ID\":\"" + r.EMAIL_ID + "\"," +
              "\"ENQUIRY_DATE\":\"" + dateapiems + "\"," +
              "\"PART_ID\":\"" + r.PART_ID + "\"," +
              "\"MODEL_ID\":\"" + r.MODEL_ID + "\"," +
              "\"CUSTOMER_VOICE\":\"" + r.CUSTOMER_VOICE + "\"," +
              "\"SOURCE\":\"" + SOURCE + "\"," +
              "\"IS_OPTED_FINANCE\":\"" + r.Finance + "\"}";

                string response = pushemsApitwo(Ems_Enquirydatanewjson);
                Update1WheelsEmsResponse(r.Finance = row["id"].ToString(), response, Ems_Enquirydatanewjson, r);
            }



        }

        public void Update1WheelsEmsResponse(string Leadid, string response, string emsjson, DropLeadRequestModel model)
        {

            string reems = response;
            reems = reems.Replace("\"", "");
            int push = 0;
            if (reems.Contains("status:SUCCESS"))
            {
                DateTime dmsdate = Convert.ToDateTime(model.ENQUIRY_DATE);
                int bucket = Convert.ToInt32(dmsdate.ToString("yyyyMMdd"));
                thresholdService.UpsertThreshold(model.DEALER_ID, model.BRANCH_ID, 1, bucket);
                push = 1;
            }

            Console.WriteLine(response);

            string qry = "update tvs_91Wheels_leads set ems_json='" + emsjson + "',ems_server_response='" + response + "',ems_push='" + push + "',repush_ems='" + push + "' where id='" + Leadid + "'";
            DataSet ds = objDbu.executeQuery(qry);

        }
        public string pushemsApitwo(string requstjson)
        {
            string result = "";
            StreamWriter mywriter = null;


            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;

            HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create("https://www.api.tvsaccelerator.com/api/save-ems-enquiry");

            objRequest.Method = "POST";
            objRequest.ContentType = "application/json";
            objRequest.Headers.Add("APIKey", "c60c2a641ba5a9f3bfdb5c18e80e9dfd456f41e708c69f07f6b2a0783dc680f9e672c8fec6dad544dc892a9004bb465daaa4cd8d89874cbcdfd920716b0f5315");

            try
            {
                mywriter = new StreamWriter(objRequest.GetRequestStream());
                mywriter.Write(requstjson);
            }
            catch (Exception exe)
            {
                result = exe.Message.ToString();
            }
            finally
            {
                mywriter.Close();
            }

            try
            {
                HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
                using (StreamReader sr =
                   new StreamReader(objResponse.GetResponseStream()))
                {
                    result = sr.ReadToEnd();
                    //   crm_push = "1";
                }
            }
            // return result;
            catch (WebException ex)
            {
                var resp = "";
                try
                {
                    resp = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
                }
                catch (Exception exe)
                {
                    result = ex.Message.ToString();
                }

                if (resp != "")
                {
                    result = resp.ToString();
                }
                else
                {

                }

                // crm_push = "0";
            }
            return result;
        }

        public void GetWebsiteEmsRepushData()
        {


            string qry = "select top 100 * ";
            qry += " from tb_tvs_common_api_leads  where CONVERT(date,create_date_get) ";
            qry += " between CONVERT(DATE,'01/06/2023',103) and CONVERT(DATE,'02/06/2023',103) ";
            qry += "   and isnull(repush_ems,0)=0 and model_id=16  ";
            qry += " and ems_server_response='{\"status\":\"ValidationError\",\"message\":\"Invalid model or part ids.\"}'";


            DataSet dswebsite = objDbu.executeQuery(qry);


            foreach (DataRow row in dswebsite.Tables[0].Rows)
            {
                DropLeadRequestModel r = new DropLeadRequestModel();


                r.DEALER_ID = row["dealer_id"].ToString();
                r.BRANCH_ID = row["BRANCH_ID"].ToString();
                r.INTERNET_ENQUIRY_ID = row["INTERNET_ENQUIRY_ID"].ToString();
                r.CUSTOMER_NAME = row["name"].ToString();
                r.GENDER = row["GENDER"].ToString();
                r.MARRIED = row["MARRIED"].ToString();
                r.ADDRESS_LINE1 = row["ADDRESS_LINE1"].ToString();
                r.AREA = row["AREA"].ToString();
                r.MOBILE_NUMBER = row["mobile"].ToString();
                r.EMAIL_ID = row["email"].ToString();
                r.PART_ID = row["PART_ID"].ToString();
                r.MODEL_ID = row["MODEL_ID_DMS"].ToString();
                r.CUSTOMER_VOICE = row["CUSTOMER_VOICE"].ToString();
                r.Finance = row["Finance"].ToString();
                r.ENQUIRY_DATE = row["create_date_get"].ToString();
                DateTime dmsdate = Convert.ToDateTime(row["create_date_get"].ToString());
                string SOURCE = "TVS Raider_corporate";
                string dateapiems = dmsdate.ToString("yyyy-MM-ddTHH:mm:ss.000Z");

                string Ems_Enquirydatanewjson = "{\"DEALER_ID\":\"" + r.DEALER_ID + "\"," +
              "\"BRANCH_ID\":\"" + r.BRANCH_ID + "\",\"INTERNET_ENQUIRY_ID\":\"" + r.INTERNET_ENQUIRY_ID + "\"," +
              "\"CUSTOMER_NAME\":\"" + r.CUSTOMER_NAME + "\",\"GENDER\":\"" + r.GENDER + "\",\"MARRIED\":\"" + r.MARRIED + "\"," +
              "\"ADDRESS_LINE1\":\"" + r.ADDRESS_LINE1 + "\",\"AREA\":\"" + r.AREA + "\"," +
              "\"PHONE_NUMBER\":\"" + r.MOBILE_NUMBER.Replace("+91", "") + "\"," +
              "\"MOBILE_NUMBER\":\"" + r.MOBILE_NUMBER.Replace("+91", "") + "\"," +
              "\"EMAIL_ID\":\"" + r.EMAIL_ID + "\"," +
              "\"ENQUIRY_DATE\":\"" + dateapiems + "\"," +
              "\"PART_ID\":\"" + r.PART_ID + "\"," +
              "\"MODEL_ID\":\"" + r.MODEL_ID + "\"," +
              "\"CUSTOMER_VOICE\":\"" + r.CUSTOMER_VOICE + "\"," +
              "\"SOURCE\":\"" + SOURCE + "\"," +
              "\"IS_OPTED_FINANCE\":\"" + r.Finance + "\"}";

                string response = pushems(Ems_Enquirydatanewjson);
                UpdateWebsiteEmsResponse(r.Finance = row["id"].ToString(), response, Ems_Enquirydatanewjson, r);
            }



        }

        public void UpdateWebsiteEmsResponse(string Leadid, string response, string emsjson, DropLeadRequestModel model)
        {

            string reems = response;
            reems = reems.Replace("\"", "");
            int push = 0;
            if (reems.Contains("status:SUCCESS"))
            {
                DateTime dmsdate = Convert.ToDateTime(model.ENQUIRY_DATE);
                int bucket = Convert.ToInt32(dmsdate.ToString("yyyyMMdd"));
                thresholdService.UpsertThreshold(model.DEALER_ID, model.BRANCH_ID, 1, bucket);
                push = 1;
            }

            Console.WriteLine(response);

            string qry = "update tb_tvs_common_api_leads set ems_json='" + emsjson + "',ems_server_response='" + response + "',ems_push='" + push + "',repush_ems='" + push + "',ems_respushdate=getdate() where id='" + Leadid + "'";
            DataSet ds = objDbu.executeQuery(qry);

        }
        public string pushems(string requstjson)
        {
            string result = "";
            StreamWriter mywriter = null;


            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;

            HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create("https://www.api.tvsaccelerator.com/api/push-online-enquiry");

            objRequest.Method = "POST";
            objRequest.ContentType = "application/json";
            objRequest.Headers.Add("APIKey", "c60c2a641ba5a9f3bfdb5c18e80e9dfd456f41e708c69f07f6b2a0783dc680f9e672c8fec6dad544dc892a9004bb465daaa4cd8d89874cbcdfd920716b0f5315");

            try
            {
                mywriter = new StreamWriter(objRequest.GetRequestStream());
                mywriter.Write(requstjson);
            }
            catch (Exception exe)
            {
                result = exe.Message.ToString();
            }
            finally
            {
                mywriter.Close();
            }

            try
            {
                HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
                using (StreamReader sr =
                   new StreamReader(objResponse.GetResponseStream()))
                {
                    result = sr.ReadToEnd();
                    //   crm_push = "1";
                }
            }
            // return result;
            catch (WebException ex)
            {
                var resp = "";
                try
                {
                    resp = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
                }
                catch (Exception exe)
                {
                    result = ex.Message.ToString();
                }

                if (resp != "")
                {
                    result = resp.ToString();
                }
                else
                {

                }

                // crm_push = "0";
            }
            return result;
        }
        public int push()
        {
            string qry = "select  * from TvsRonin_missed_leads where isnull(lead_push,0)=0";
            DataSet ds = objDbu.executeQuery(qry);
            int i = 0;
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                i++;
                Console.WriteLine("Lead row: " + i);
                DropLeadRequestModel requestModel = new DropLeadRequestModel();
                requestModel.CUSTOMER_NAME = Convert.ToString(dr["CustomerName"]);
                requestModel.DEALER_ID = Convert.ToString(dr["DEALERID"]);
                requestModel.MOBILE_NUMBER = Convert.ToString(dr["MobileNumber"]);

                if (Convert.ToString(dr["EmailId"]) == "NULL")
                {
                    requestModel.EMAIL_ID = "";
                }
                else
                {
                    requestModel.EMAIL_ID = Convert.ToString(dr["EmailId"]);
                }


                DateTime uploaddt = Convert.ToDateTime(dr["ENQUIRYDATE"]);

                requestModel.ENQUIRY_DATE = uploaddt.ToString("yyyy-MM-dd HH:mm:ss.fff");
                requestModel.city = Convert.ToString(dr["City"]);
                //requestModel.username = ConfigurationManager.AppSettings["apiusername"].ToString();
                //requestModel.password = ConfigurationManager.AppSettings["apipassword"].ToString();

                requestModel.username = "tvscommon";
                requestModel.password = "motor!@$";



                requestModel.utm_source = Convert.ToString(dr["UtmSource"]);
                requestModel.utm_medium = Convert.ToString(dr["UtmMedium"]);
                requestModel.utm_campaign = Convert.ToString(dr["UtmCampaign"]);
                requestModel.gclid = Convert.ToString(dr["Gclid"]);
                requestModel.language_code = 1;
                requestModel.SOURCE = "dmsapi";
                requestModel.AREA = Convert.ToString(dr["AREA"]);
                requestModel.MODEL_ID = "0000" + Convert.ToString(dr["MODEL_ID"]);
                requestModel.PART_ID = Convert.ToString(dr["PART_ID"]);
                requestModel.CUSTOMER_VOICE = "null";
                requestModel.BRANCH_ID = Convert.ToString(dr["BRANCH_ID"]);
                requestModel.ADDRESS_LINE1 = "";
                requestModel.utm_term = "";
                requestModel.utm_content = Convert.ToString(dr["utmContent"]);
                requestModel.parm1 = Convert.ToString(dr["parm1"]);
                requestModel.parm2 = Convert.ToString(dr["parm2"]);
                requestModel.parm3 = Convert.ToString(dr["parm3"]);
                requestModel.parm4 = Convert.ToString(dr["parm4"]);
                requestModel.parm5 = Convert.ToString(dr["parm4"]);
                requestModel.CUSTOMER_STATE = Convert.ToString(dr["state"]);

                requestModel.Finance = Convert.ToString(dr["interestInFinance"]);

                requestModel.pincode = Convert.ToString(dr["AREA"]);
                requestModel.Finance_Company = Convert.ToString(dr["FinanceCompany"]);
                requestModel.IntentforPurchase = Convert.ToString(dr["purchasePlan"]);
                requestModel.Device = "";
                requestModel.brand_code = 19;
                LeadResponse response = LeadPush(requestModel);

                UpdateResponse(Convert.ToString(dr["Id"]), response);
            }

            return 1;



        }
        public void UpdateResponse(string ID, LeadResponse response)
        {
            int push = 0;
            if (response.status)
            {
                push = 1;
            }
            string qry = "update TvsRonin_missed_leads set ApiResponse='" + response.msg + "',lead_push='" + push + "',leadid='" + response.lead_id + "' where id='" + ID + "'";
            DataSet ds = objDbu.executeQuery(qry);

        }
        public LeadResponse LeadPush(DropLeadRequestModel requestModel)
        {
            LeadResponse leadResponse = new LeadResponse();
            try
            {

                string json = Newtonsoft.Json.JsonConvert.SerializeObject(requestModel);


                // Log4net.Info("TvsEmsDmsCommonDropLeads Request:" + json);

                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                string result = "";
                StreamWriter mywriter = null;
                HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create("http://api.tvsmotor.com/Tvsapi.svc/TvsEmsDmsCommon");

                objRequest.Method = "POST";
                objRequest.ContentType = "application/json";
                objRequest.Headers.Add("Authorization", "406557EB82E651EE239EE47956DAD519ED196899F482AE417C31473DA234842BBB5206266F5F6846EE0E729DBEF23999126E6A7009648004DF0B2E134517A6CC");

                try
                {
                    mywriter = new StreamWriter(objRequest.GetRequestStream());
                    mywriter.Write(json);
                }
                catch (Exception exe)
                {
                    result = exe.Message.ToString();
                }
                finally
                {
                    mywriter.Close();
                }

                try
                {
                    HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
                    using (StreamReader sr =
                       new StreamReader(objResponse.GetResponseStream()))
                    {
                        result = sr.ReadToEnd();
                        // Log4net.Info("TvsEmsDmsCommonDropLeads Response:" + result);
                        leadResponse = Newtonsoft.Json.JsonConvert.DeserializeObject<LeadResponse>(result);

                    }
                }
                // return result;
                catch (WebException ex)
                {
                    // Log4net.Error("TvsEmsDmsCommonDropLeads Response:", ex);
                    leadResponse.status = false;
                    leadResponse.msg = ex.ToString();

                    // crm_push = "0";
                }
                return leadResponse;
            }
            catch (Exception ex)
            {
                leadResponse.status = false;
                leadResponse.msg = ex.ToString();
            }
            return leadResponse;

        }
    }
}
