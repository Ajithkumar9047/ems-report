﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace LeadPush.GUtils
{
    public class Utils
    {
        string strOutput = "";
        DBUtils dbu = new DBUtils();

        public string getRandomKey()
        {
            Random rn = new Random(50);
            return "rn" + rn.NextDouble().ToString().Replace(".", "VC");
        }
        public string CleanQueryString(string strParam) //to avoid SQL Injection
        {
            strParam = strParam.Replace("'", "''").Replace("\"\"", "").Replace(")", "").Replace("(", "").Replace("-", "").Replace("|", "").Replace(";", "");
            return strParam;
        }
        public string SqlFriendly(string value)
        {
            return value.Replace("'", "''");
        }
        public string CleanPageUrl(string strParam) //to avoid SQL Injection
        {
            strParam = strParam.Replace("'", "''").Replace("\"\"", "").Replace(")", "").Replace("(", "").Replace("declare", "").Replace("cast", "").Replace("|", "").Replace(";", "");
            return strParam;
        }
        public bool hasData(DataSet dsTemp)
        {
            if (dsTemp != null)
                if (dsTemp.Tables.Count > 0)
                    if (dsTemp.Tables[0].Rows.Count > 0)
                        return true;
            return false;
        }
    }
}
