﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeadPush
{
    public class DropLeadRequestModel
    {
        public string DEALER_ID = "";
        public string BRANCH_ID = "";
        public string CUSTOMER_NAME = "";
        public string GENDER = "";
        public string MARRIED = "";
        public string ADDRESS_LINE1 = "";
        public string AREA = "";
        public string MOBILE_NUMBER = "";
        public string EMAIL_ID = "";
        public string ENQUIRY_DATE = "";
        public string PART_ID = "";
        public string MODEL_ID = "";
        public string CUSTOMER_VOICE = "";
        public string username = "";
        public string password = "";
        public string SOURCE = "";
        public int brand_code = 0;
        public string utm_source = "";
        public string utm_medium = "";
        public string utm_campaign = "";
        public string gclid = "";
        public string city = "";
        public int language_code = 0;
        public string utm_term = "";
        public string utm_content = "";
        public string parm1 = "";
        public string parm2 = "";
        public string parm3 = "";
        public string parm4 = "";
        public string parm5 = "";

        public string CUSTOMER_CITY = "";
        public string CUSTOMER_STATE = "";
        public string Finance = "";

        public string pincode = "";

        public string Finance_Company = "";

        public string IntentforPurchase = "";

        public string Device = "";
        public string INTERNET_ENQUIRY_ID = "";
    }
}
