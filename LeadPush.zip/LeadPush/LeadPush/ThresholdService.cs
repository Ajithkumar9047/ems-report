﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using LeadPush.GUtils;

namespace LeadPush
{



    public class ThresholdService
    {
        DBUtils dbu = new DBUtils();



        public LeadPush.ThresholdModel GetThresholdLevel(string dealerId,string branchid,int bucket)
        {
            LeadPush.ThresholdModel thresholdModel = new LeadPush.ThresholdModel();

            string getDealer = "select isnull(count,0) as count,isnull(maxcount,0) as Threshold  from TVSDealerThresholdFeeds where dealerId='" + dealerId + "'" + "and bucket='"+ bucket + "' and branchId='" + branchid+"'";
            DataSet dslan = dbu.executeQuery(getDealer);
            if (dslan != null && dslan.Tables[0].Rows.Count > 0)
            {
                thresholdModel.CurrentDayCount = Convert.ToInt32(dslan.Tables[0].Rows[0]["count"]);
                thresholdModel.Rowexists = true;
                thresholdModel.Threshold = Convert.ToInt32(dslan.Tables[0].Rows[0]["Threshold"]);

            }
            else
            {
                thresholdModel.Threshold = 9999;
            }

           // thresholdModel.Threshold = getDealerThreshold(dealerId,branchid);
            return thresholdModel;

        }


        public int UpsertThreshold(string dealerId,string branchid,int count,int bucket)
        {
            int Crmpushed = 0;
            if (count == 0)
            {
                Crmpushed = 1;
            }
            int row = -1;
            LeadPush.ThresholdModel thresholdModel = GetThresholdLevel(dealerId,branchid,bucket);

            if (!thresholdModel.Rowexists)
            {
                if(thresholdModel.Threshold==0)
                {
                    thresholdModel.Threshold = 9999;
                }
              
                string insertqry = "insert into TVSDealerThresholdFeeds(DealerId,count,bucket,maxcount,branchId,TotalCount,CrmPushed)values('" + dealerId + "','"+count+"','"+ bucket + "','"+ thresholdModel.Threshold + "','"+branchid+"','1','"+ Crmpushed + "')";

                dbu.executeQuery(insertqry);    

                row = 1;
            }
            else if (thresholdModel.Threshold > thresholdModel.CurrentDayCount)
            {

                string updateCount = "update TVSDealerThresholdFeeds set count =isnull(count,0)+" + count+ ",TotalCount=isnull(TotalCount,0)+1,CrmPushed=isnull(CrmPushed,0)+" + Crmpushed + " where DealerId='" + dealerId + "' and bucket='"+bucket+"' and branchId='"+branchid+"' ";
                dbu.executeQuery(updateCount);
                row = 2;
            }
            //overflow update only crm
            else
            {
                string updateCount = "update TVSDealerThresholdFeeds set count=isnull(count,0)+" + count+ ",TotalCount=isnull(TotalCount,0)+1,CrmPushed=isnull(CrmPushed,0)+" + Crmpushed + " where DealerId='" + dealerId + "' and bucket='"+bucket+"' and branchId='" + branchid + "' ";
                dbu.executeQuery(updateCount);
                row = 2;
            }

            return row;
        }
        public int getDealerThreshold(string dealerId,string branchid)
        {
            int thresholdCount = 0;

            string getDealerThresholdqry = "select  top 1 isnull(threshold,0) as thresholdCount  from ThresholdMaster where dealer_id='" + dealerId + "' and branch_id='" + branchid+ "' order by created_on desc";
            DataSet dsThresold = dbu.executeQuery(getDealerThresholdqry);
            if (dsThresold != null && dsThresold.Tables[0].Rows.Count > 0)
            {
                thresholdCount = Convert.ToInt32(dsThresold.Tables[0].Rows[0]["thresholdCount"]);
            }

            return thresholdCount;


        }
    }
}