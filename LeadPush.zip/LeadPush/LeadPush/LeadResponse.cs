﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeadPush
{
    public class LeadResponse
    {
        public string result = "";
        public bool status = false;
        public string msg = "";
        public string lead_id = "";
        public string dmsapirespone = "";
        public string crmapirespone = "";
        public string emsresponse = "";
    }
}
